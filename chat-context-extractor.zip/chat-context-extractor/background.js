// ── BACKGROUND SERVICE WORKER ────────────────────────────────────────
// Handles keyboard shortcut, context menu, badge, and storage helpers

// Context menu on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus?.create({
    id: 'cce-extract',
    title: 'Extract Chat Context',
    contexts: ['page'],
    documentUrlPatterns: [
      'https://chatgpt.com/*',
      'https://chat.openai.com/*',
      'https://claude.ai/*',
      'https://gemini.google.com/*'
    ]
  });
  updateBadge();
});

// Context menu click → open popup
chrome.contextMenus?.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'cce-extract') {
    chrome.action.openPopup?.();
  }
});

// Keyboard shortcut
chrome.commands.onCommand.addListener((command) => {
  if (command === 'trigger-extraction') {
    chrome.action.openPopup?.();
  }
});

// Update badge with session count
function updateBadge() {
  chrome.storage.local.get('cce_sessions', (data) => {
    const sessions = data.cce_sessions || [];
    const count = sessions.length;
    chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#6c63ff' });
  });
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Only accept messages from our own extension pages
  if (sender.id !== chrome.runtime.id) return;
  if (msg.type === 'UPDATE_BADGE') {
    updateBadge();
    sendResponse({ ok: true });
  }
  if (msg.type === 'SCRAPE_CHAT') {
    // Forward scrape request to content script in active tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.id) {
        sendResponse({ error: 'No active tab' });
        return;
      }
      // Check if tab URL is a supported platform
      const url = tab.url || '';
      const supported = ['chatgpt.com', 'chat.openai.com', 'claude.ai', 'gemini.google.com'];
      const platform = supported.find(p => url.includes(p));
      if (!platform) {
        sendResponse({ error: 'not_supported', url });
        return;
      }
      chrome.tabs.sendMessage(tab.id, { type: 'SCRAPE', platform }, (response) => {
        if (chrome.runtime.lastError) {
          // Content script not ready — inject and retry
          chrome.scripting.executeScript(
            { target: { tabId: tab.id }, files: ['content.js'] },
            () => {
              setTimeout(() => {
                chrome.tabs.sendMessage(tab.id, { type: 'SCRAPE', platform }, (r) => {
                  sendResponse(r || { error: 'Script injection failed' });
                });
              }, 600);
            }
          );
        } else {
          sendResponse(response || { error: 'No response from content script' });
        }
      });
    });
    return true; // async
  }
});
