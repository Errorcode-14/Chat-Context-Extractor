// Full mode detection — runs immediately on load
if (new URLSearchParams(window.location.search).get("fullmode") === "1") {
  document.documentElement.classList.add("fullmode-root");
  document.documentElement.style.cssText = "width:100vw;max-height:none;overflow:auto";
  // body may not exist yet — use MutationObserver as fallback
  if (document.body) {
    document.body.classList.add("fullmode");
    document.body.style.cssText = "width:100vw;max-height:none;overflow:auto";
  } else {
    new MutationObserver((_, obs) => {
      if (document.body) {
        document.body.classList.add("fullmode");
        document.body.style.cssText = "width:100vw;max-height:none;overflow:auto";
        obs.disconnect();
      }
    }).observe(document.documentElement, { childList: true });
  }
}

// ── STATE ─────────────────────────────────────────────────────────────
let files = [];
let sessions = [];
let editMode = false;
let promptLocked = false;
let selectedTemplate = null;
let mergeSelected = [];
let currentPlatform = null;
let autosaveTimer = null;

const TEMPLATES = [
  { id: 'continue', name: 'Continue Project', text: 'Here is structured context from a previous conversation including output files. Use this to understand exactly where I left off and continue building from here. Jump straight into next steps.' },
  { id: 'debug', name: 'Debug Code', text: 'Here is context from a previous coding session including the files produced. Analyze the code carefully, identify bugs or issues, and help me fix them.' },
  { id: 'beginner', name: "I'm a Beginner", text: 'Here is context from a previous conversation. I am still learning — explain clearly, avoid jargon, and guide me step by step.' },
  { id: 'review', name: 'Review & Improve', text: 'Here is context and files from a previous session. Critically review the code and approach, suggest improvements, and identify what could be better.' },
  { id: 'new-ai', name: 'New AI, Same Project', text: 'I am switching to you from another AI. Here is full context of what we discussed and built. Treat this as if you were the AI that helped me build this from the start.' },
  { id: 'expand', name: 'Expand on This', text: 'Here is context from a previous conversation. I want to expand — add more features, improve robustness, and take the project further.' },
  { id: 'convo', name: 'Continue Conversation', text: 'Here is context from a previous conversation. Use this to understand what was discussed and continue naturally from where we left off. No need to re-explain anything — just pick up the thread.' },
];

// ── HELPERS ───────────────────────────────────────────────────────────
function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function isOn(id) {
  return document.getElementById(id)?.classList.contains('on');
}
function tog(el) {
  el.classList.toggle('on');
  autoSaveState();
}
function $(id) { return document.getElementById(id); }

// ── NAV ───────────────────────────────────────────────────────────────
function sw(name) {
  ['chat', 'files', 'extract', 'prompt', 'sessions', 'guide'].forEach(n => {
    $('tab-btn-' + n)?.classList.toggle('active', n === name);
    $('panel-' + n)?.classList.toggle('active', n === name);
  });
}

// ── COLLAPSIBLE BLOCKS ────────────────────────────────────────────────
function togB(header) {
  const body = header.nextElementSibling;
  const chev = header.querySelector('.chev');
  if (!body) return;
  body.classList.toggle('collapsed');
  chev.style.transform = body.classList.contains('collapsed') ? 'rotate(-90deg)' : '';
}

// ── COPY BUTTONS ──────────────────────────────────────────────────────
function copyText(text, btnId, origLabel, doneLabel) {
  if (!text || !text.trim()) return;
  navigator.clipboard.writeText(text).then(() => {
    const btn = $(btnId);
    if (!btn) return;
    btn.classList.add('copied');
    btn.innerHTML = doneLabel;
    setTimeout(() => {
      btn.classList.remove('copied');
      btn.innerHTML = origLabel;
    }, 2200);
  });
}

// ── TOKEN METER ───────────────────────────────────────────────────────
function countTokens(text) { return Math.ceil((text || '').length / 4); }

function renderTokenMeter(containerId, text) {
  const el = $(containerId);
  if (!el) return;
  const t = countTokens(text);
  const limits = [
    { label: 'GPT-3.5', max: 16000 },
    { label: 'GPT-4o', max: 128000 },
    { label: 'Claude', max: 200000 },
  ];
  el.innerHTML = `<div class="tm-title">Context Size</div>` +
    limits.map(l => {
      const pct = Math.min((t / l.max) * 100, 100);
      const color = pct > 90 ? 'var(--r)' : pct > 60 ? 'var(--o)' : 'var(--g)';
      return `<div class="tm-row"><span class="tm-label">${l.label}</span><span class="tm-label" style="color:${color}">${pct < 1 ? '<1' : Math.round(pct)}%</span></div><div class="tm-bar"><div class="tm-fill" style="width:${pct}%;background:${color}"></div></div>`;
    }).join('') +
    `<div class="tm-total">${t.toLocaleString()} tokens</div>`;
}

// ── PLATFORM DETECTION ────────────────────────────────────────────────
function detectPlatform() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const url = tabs[0]?.url || '';
    const dot = $('platform-dot');
    const name = $('platform-name');
    const scrapeBtn = $('scrape-btn');

    if (url.includes('chatgpt.com') || url.includes('chat.openai.com')) {
      currentPlatform = 'chatgpt';
      dot.className = 'platform-dot detected';
      name.className = 'platform-name detected';
      name.textContent = 'ChatGPT detected — ready to scrape';
      scrapeBtn.disabled = false;
    } else if (url.includes('claude.ai')) {
      currentPlatform = 'claude';
      dot.className = 'platform-dot detected';
      name.className = 'platform-name detected';
      name.textContent = 'Claude detected — ready to scrape';
      scrapeBtn.disabled = false;
    } else if (url.includes('gemini.google.com')) {
      currentPlatform = 'gemini';
      dot.className = 'platform-dot detected';
      name.className = 'platform-name detected';
      name.textContent = 'Gemini detected — best effort scrape';
      scrapeBtn.disabled = false;
    } else {
      currentPlatform = null;
      dot.className = 'platform-dot error';
      name.className = 'platform-name';
      name.textContent = url ? 'Not an AI chat page — paste manually' : 'No page detected';
      scrapeBtn.disabled = true;
    }
  });
}

function detectAndScrape() {
  if (!currentPlatform) return;
  const scrapeBtn = $('scrape-btn');
  const status = $('scrape-status');
  scrapeBtn.disabled = true;
  scrapeBtn.textContent = '⏳ Scraping...';
  status.innerHTML = '';

  chrome.runtime.sendMessage({ type: 'SCRAPE_CHAT' }, (response) => {
    scrapeBtn.disabled = false;
    scrapeBtn.textContent = '⚡ Auto-Scrape This Chat';
    $('refresh-scrape-btn').style.display = 'inline-flex';

    if (!response || response.error) {
      const errMsg = response?.error === 'not_supported'
        ? 'This page is not a supported AI chat.'
        : response?.error === 'no_messages'
        ? 'Could not find messages. Scroll through the full conversation to load all messages, then re-scrape — or paste manually below.'
        : 'Scrape failed. Paste manually below.';
      // Use textContent to avoid XSS from error strings
      const warnEl = document.createElement('div');
      warnEl.className = 'warn';
      warnEl.textContent = errMsg;
      status.innerHTML = '';
      status.appendChild(warnEl);
      return;
    }

    if (response.ok && response.text) {
      $('chat-input').value = response.text;
      const tipEl = document.createElement('div');
      tipEl.className = 'tip';
      // Safe — currentPlatform is from our own URL check, count is a number
      tipEl.textContent = `✓ Scraped ${Number(response.count)} messages from ${currentPlatform}. Review below or hit Extract.`;
      status.innerHTML = '';
      status.appendChild(tipEl);
      autoSaveState();
    }
  });
}

// ── FILE MANAGEMENT ───────────────────────────────────────────────────
function detectType(name) {
  const ext = name.split('.').pop().toLowerCase();
  return { py: 'py', js: 'js', ts: 'js', jsx: 'js', tsx: 'js', json: 'json', yaml: 'yaml', yml: 'yaml', html: 'html', htm: 'html', css: 'css', md: 'md', txt: 'txt', sh: 'sh', bash: 'sh', rb: 'py', php: 'py', go: 'py', rs: 'py', java: 'py', cpp: 'py' }[ext] || 'file';
}
function typeLabel(t) {
  return { py: 'PY', js: 'JS', json: 'JSON', yaml: 'YAML', html: 'HTML', css: 'CSS', md: 'MD', txt: 'TXT', sh: 'SH', file: 'FILE' }[t] || 'FILE';
}

function summarizeFile(name, content, type) {
  const lines = content.split('\n');
  const lc = lines.length, cc = content.length;
  const isLarge = lc > 80 || cc > 3000;
  let s = `FILE: ${name}\nTYPE: ${type.toUpperCase()}\nLINES: ${lc} | CHARS: ${cc}\n`;
  if (type === 'py' || type === 'js') {
    const fpy = [...content.matchAll(/^def\s+(\w+)\s*\(/gm)].map(m => m[1]);
    const fjs = [...content.matchAll(/(?:function\s+(\w+)|const\s+(\w+)\s*=\s*(?:async\s*)?\()/gm)].map(m => m[1] || m[2]);
    const fns = [...new Set([...fpy, ...fjs])].filter(Boolean).slice(0, 10);
    const ipy = [...content.matchAll(/^(?:import|from)\s+([\w.]+)/gm)].map(m => m[1]);
    const ijs = [...content.matchAll(/(?:import|require)\s*\(?['"`]([\w@/./-]+)/gm)].map(m => m[1]);
    const imps = [...new Set([...ipy, ...ijs])].slice(0, 10);
    const cls = [...content.matchAll(/^class\s+(\w+)/gm)].map(m => m[1]).slice(0, 5);
    if (fns.length) s += `FUNCTIONS: ${fns.join(', ')}\n`;
    if (cls.length) s += `CLASSES: ${cls.join(', ')}\n`;
    if (imps.length) s += `DEPENDENCIES: ${imps.join(', ')}\n`;
    const purposes = [];
    if (/requests|httpx|fetch|axios/i.test(content)) purposes.push('HTTP');
    if (/beautifulsoup|scrapy|playwright|selenium/i.test(content)) purposes.push('scraping');
    if (/pandas|numpy|dataframe/i.test(content)) purposes.push('data');
    if (/flask|fastapi|express|django/i.test(content)) purposes.push('web server');
    if (/sqlite|postgres|mysql|mongodb/i.test(content)) purposes.push('database');
    if (/openai|anthropic|gemini|llm/i.test(content)) purposes.push('AI/LLM');
    if (purposes.length) s += `PURPOSE: ${purposes.join(', ')}\n`;
  } else if (type === 'json') {
    try { const obj = JSON.parse(content); s += `TOP_KEYS: ${Object.keys(obj).slice(0, 10).join(', ')}\n`; } catch { s += 'NOTE: non-standard JSON\n'; }
  } else if (type === 'yaml') {
    const keys = [...content.matchAll(/^(\w[\w-]*):/gm)].map(m => m[1]);
    s += `TOP_KEYS: ${[...new Set(keys)].slice(0, 10).join(', ')}\n`;
  } else if (type === 'md') {
    const hdgs = [...content.matchAll(/^#{1,3}\s+(.*)/gm)].map(m => m[1]).slice(0, 8);
    if (hdgs.length) s += `SECTIONS: ${hdgs.join(' | ')}\n`;
  }
  s += `SIZE: ${isLarge ? 'LARGE' : 'SMALL'}\n`;
  return { summary: s, isLarge };
}

function handleFiles(fl) {
  [...fl].forEach(f => { const r = new FileReader(); r.onload = e => addFile(f.name, e.target.result); r.readAsText(f); });
}
function addPastedFile() {
  const name = $('paste-name').value.trim() || 'untitled.txt';
  const content = $('paste-content').value;
  if (!content.trim()) { alert('Paste file content first.'); return; }
  addFile(name, content);
  $('paste-name').value = '';
  $('paste-content').value = '';
}
const MAX_FILE_SIZE = 500 * 1024; // 500KB limit
function addFile(name, content) {
  if (content.length > MAX_FILE_SIZE) {
    alert(`File "${name}" is too large (${Math.round(content.length/1024)}KB). Max is 500KB. Consider using SUMMARY mode or trimming the file.`);
    return;
  }
  const id = 'f' + Date.now() + Math.random().toString(36).slice(2, 5);
  const type = detectType(name);
  const { summary, isLarge } = summarizeFile(name, content, type);
  files.push({ id, name, content, type, summary, isLarge, mode: isLarge ? 'summary' : 'full' });
  renderFiles(); updateBadge(); autoSaveState();
}
function removeFile(id) {
  files = files.filter(f => f.id !== id);
  renderFiles(); updateBadge(); autoSaveState();
}
function setFileMode(id, mode) {
  const f = files.find(f => f.id === id);
  if (f) { f.mode = mode; renderFiles(); }
}
function clearFiles() {
  files = [];
  renderFiles(); updateBadge(); autoSaveState();
}
function updateBadge() {
  const b = $('file-badge');
  if (files.length) { b.style.display = 'inline'; b.textContent = files.length; }
  else b.style.display = 'none';
}

function renderFiles() {
  const list = $('file-list');
  const empty = $('files-empty');
  list.innerHTML = '';
  if (!files.length) { empty.style.display = 'block'; return; }
  empty.style.display = 'none';
  files.forEach(f => {
    const d = document.createElement('div');
    d.className = 'file-card';
    const safeType = f.type.replace(/[^a-z]/g, '');
    d.innerHTML = `
      <div class="fc-hdr">
        <div class="fc-ico ic-${safeType}">${typeLabel(f.type)}</div>
        <div class="fc-info">
          <div class="fc-name">${esc(f.name)}</div>
          <div class="fc-meta">${f.content.split('\n').length} lines · ${f.isLarge ? 'auto-summ' : 'small'}</div>
        </div>
        <div style="display:flex;gap:3px;align-items:center">
          <div class="fc-toggle">
            <button class="fc-tbtn ${f.mode === 'summary' ? 'active' : ''}" data-id="${f.id}" data-mode="summary">SUM</button>
            <button class="fc-tbtn ${f.mode === 'full' ? 'active' : ''}" data-id="${f.id}" data-mode="full">FULL</button>
          </div>
          <button class="btn-sm r remove-file-btn" data-id="${f.id}" style="padding:2px 6px;font-size:.54rem">×</button>
        </div>
      </div>`;
    list.appendChild(d);
  });

  // Wire file buttons (no inline handlers)
  list.querySelectorAll('.fc-tbtn').forEach(btn => {
    btn.addEventListener('click', () => setFileMode(btn.dataset.id, btn.dataset.mode));
  });
  list.querySelectorAll('.remove-file-btn').forEach(btn => {
    btn.addEventListener('click', () => removeFile(btn.dataset.id));
  });
}

// ── SMART EXTRACTION ENGINE ───────────────────────────────────────────
function smartExtract(chat) {
  const lines = chat.split('\n').map(l => l.trim()).filter(Boolean);
  const msgs = []; let cur = null;
  for (const l of lines) {
    const um = l.match(/^(User|Human|You|Me)\s*[:>]\s*(.*)/i);
    const am = l.match(/^(Assistant|AI|Bot|Claude|GPT|Gemini|ChatGPT|Bard)\s*[:>]\s*(.*)/i);
    if (um) { if (cur) msgs.push(cur); cur = { role: 'user', text: um[2] }; }
    else if (am) { if (cur) msgs.push(cur); cur = { role: 'ai', text: am[2] }; }
    else if (cur) cur.text += ' ' + l;
  }
  if (cur) msgs.push(cur);
  if (msgs.length < 2) lines.forEach((l, i) => msgs.push({ role: i % 2 === 0 ? 'user' : 'ai', text: l }));

  const userMsgs = msgs.filter(m => m.role === 'user').map(m => m.text);
  const aiMsgs = msgs.filter(m => m.role === 'ai').map(m => m.text);
  const stopwords = new Set('the a an is are was were be been have has had do does did will would could should may might must i you he she it we they them their this that these those of in on at to for with from by about into'.split(' '));
  const freq = {};
  chat.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).forEach(w => { if (w.length > 3 && !stopwords.has(w)) freq[w] = (freq[w] || 0) + 1; });
  const topWords = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 25).map(e => e[0]);

  const techList = ['python', 'javascript', 'typescript', 'react', 'vue', 'node', 'express', 'fastapi', 'flask', 'django', 'sql', 'postgresql', 'mysql', 'mongodb', 'redis', 'docker', 'kubernetes', 'git', 'aws', 'linux', 'bash', 'api', 'rest', 'graphql', 'scraping', 'beautifulsoup', 'selenium', 'playwright', 'requests', 'pandas', 'numpy', 'tensorflow', 'pytorch', 'openai', 'anthropic', 'langchain', 'nginx'];
  const foundTech = techList.filter(t => chat.toLowerCase().includes(t));

  const intentVerbs = {
    build: ['build', 'create', 'make', 'write', 'implement', 'code', 'develop', 'set up'],
    fix: ['fix', 'debug', 'error', 'broken', 'not working', 'issue', 'bug'],
    understand: ['understand', 'explain', 'what is', 'how does', 'learn', 'clarify'],
    optimize: ['optimize', 'improve', 'performance', 'refactor', 'enhance'],
    deploy: ['deploy', 'production', 'host', 'publish']
  };
  const detectedIntents = [];
  const au = userMsgs.join(' ').toLowerCase();
  Object.entries(intentVerbs).forEach(([intent, verbs]) => {
    if (verbs.some(v => au.includes(v))) detectedIntents.push(intent);
  });

  const entities = { files: [], urls: [], versions: [], errors: [] };
  entities.files = [...new Set([...chat.matchAll(/\b[\w-]+\.(py|js|ts|json|yaml|html|css|sh|md|txt)\b/gi)].map(m => m[0]))].slice(0, 8);
  entities.urls = [...new Set([...chat.matchAll(/https?:\/\/[^\s<>"]+/g)].map(m => m[0]))].slice(0, 4);
  entities.versions = [...new Set([...chat.matchAll(/\bv?\d+\.\d+(?:\.\d+)?\b/g)].map(m => m[0]))].slice(0, 6);
  entities.errors = [...new Set([...chat.matchAll(/\b([A-Z][a-zA-Z]+(?:Error|Exception|Warning))\b/g)].map(m => m[1]))].slice(0, 5);

  const goalWords = ['want to', 'trying to', 'need to', 'goal', 'plan to', 'learning', 'working on', 'building', 'preparing'];
  const goals = [];
  userMsgs.forEach(m => {
    goalWords.forEach(g => {
      if (m.toLowerCase().includes(g)) {
        const idx = m.toLowerCase().indexOf(g);
        goals.push(m.substring(idx, idx + 100).trim());
      }
    });
  });

  const skillSignals = {
    NOVICE: ['what is', 'never used', 'new to', 'beginner', 'just started'],
    INTERMEDIATE: ['how to', 'configure', 'set up', 'implement', 'getting error'],
    ADVANCED: ['optimize', 'architecture', 'production', 'scale', 'best practice']
  };
  let skillLevel = 'BEGINNER';
  if (skillSignals.ADVANCED.some(w => au.includes(w))) skillLevel = 'ADVANCED';
  else if (skillSignals.INTERMEDIATE.some(w => au.includes(w))) skillLevel = 'INTERMEDIATE';
  else if (skillSignals.NOVICE.some(w => au.includes(w))) skillLevel = 'NOVICE';

  const conflictSignals = ['actually', 'wait no', 'instead', 'changed my mind', 'forget that', 'scratch that'];
  const conflicts = userMsgs.filter(m => conflictSignals.some(s => m.toLowerCase().includes(s)));

  function scoreMsg(m) {
    let sc = 0;
    const ml = m.toLowerCase();
    if (ml.includes('?')) sc += 15;
    if (goalWords.some(g => ml.includes(g))) sc += 20;
    if (foundTech.some(t => ml.includes(t))) sc += 10;
    if (/\b(important|must|need|require)\b/i.test(m)) sc += 12;
    if (m.length > 80) sc += 5;
    return sc;
  }

  const blocks = [];
  for (let i = 0; i < msgs.length - 1; i++) {
    if (msgs[i].role === 'user' && msgs[i + 1]?.role === 'ai') {
      const resolveSignals = ['that works', 'solved', 'fixed', 'perfect', 'thank', 'works now', 'makes sense'];
      const resolved = resolveSignals.some(s => msgs[i + 1].text.toLowerCase().includes(s));
      blocks.push({ q: msgs[i].text, a: msgs[i + 1].text, resolved, importance: scoreMsg(msgs[i].text), idx: i + 1 });
    }
  }
  const sortedBlocks = [...blocks].sort((a, b) => b.importance - a.importance);
  const questions = userMsgs.filter(m => m.includes('?') || /^(what|how|why|when|can|should)/i.test(m)).slice(0, 6);

  return { blocks, sortedBlocks, userMsgs, aiMsgs, topWords, foundTech, goals, questions, conflicts, entities, detectedIntents, skillLevel };
}

function buildLocalOutput(result) {
  const { blocks, sortedBlocks, userMsgs, aiMsgs, topWords, foundTech, goals, questions, conflicts, entities, detectedIntents, skillLevel } = result;
  let out = '';

  out += '## [INTERACTION_FLOW]\n';
  blocks.slice(0, 12).forEach(b => {
    const rank = sortedBlocks.findIndex(s => s.idx === b.idx);
    const total = blocks.length;
    const imp = rank === 0 ? 'CRITICAL' : rank < Math.ceil(total * 0.25) ? 'HIGH' : rank < Math.ceil(total * 0.6) ? 'MEDIUM' : 'LOW';
    out += `\nBLOCK_${b.idx}:\n  INTENT: ${b.q.substring(0, 130).replace(/\n/g, ' ')}\n  AI_RESPONSE: ${b.a.substring(0, 110).replace(/\n/g, ' ')}\n  STATUS: ${b.resolved ? 'RESOLVED' : 'OPEN'}\n`;
    if (isOn('o-importance')) out += `  IMPORTANCE: ${imp}\n`;
  });

  out += '\n## [MEMORY_LAYER]\n';
  foundTech.slice(0, 8).forEach(t => { const c = isOn('o-confidence') ? ' | MEDIUM' : ''; out += `[TOOL${c}] ${t}\n`; });
  goals.slice(0, 5).forEach(g => { const c = isOn('o-confidence') ? ' | MEDIUM' : ''; out += `[GOAL${c}] ${g.substring(0, 100)}\n`; });
  if (topWords.slice(0, 4).length) { const c = isOn('o-confidence') ? ' | HIGH' : ''; out += `[DOMAIN${c}] ${topWords.slice(0, 4).join(', ')}\n`; }

  if (isOn('o-entities')) {
    out += '\n## [NAMED_ENTITIES]\n';
    if (entities.files.length) out += `FILES: ${entities.files.join(', ')}\n`;
    if (entities.urls.length) out += `URLS: ${entities.urls.join(', ')}\n`;
    if (entities.versions.length) out += `VERSIONS: ${entities.versions.join(', ')}\n`;
    if (entities.errors.length) out += `ERRORS: ${entities.errors.join(', ')}\n`;
  }

  out += '\n## [INTENT_SUMMARY]\n';
  out += `TOPIC: ${topWords.slice(0, 4).join(', ')}\nDETECTED_INTENTS: ${detectedIntents.join(', ') || 'general'}\nUSER_MSGS: ${userMsgs.length} | AI_MSGS: ${aiMsgs.length}\nQUESTIONS:\n`;
  questions.slice(0, 3).forEach(q => out += `  - ${q.substring(0, 90)}\n`);

  out += '\n## [TOPIC_MAP]\n';
  out += `MAIN_TOPICS: ${topWords.slice(0, 7).join(', ')}\nTECHNOLOGIES: ${foundTech.join(', ') || 'none'}\n`;

  if (isOn('o-progression')) { out += '\n## [SKILL_PROGRESSION]\n'; out += `LEVEL: ${skillLevel}\nTECH_BREADTH: ${foundTech.length}\n`; }
  if (isOn('o-conflict')) { out += '\n## [CONFLICT_DETECTION]\n'; if (conflicts.length) conflicts.slice(0, 3).forEach((c, i) => out += `C${i + 1}: ${c.substring(0, 110)}\n`); else out += 'NONE_DETECTED\n'; }
  if (isOn('o-suggestions')) { out += '\n## [AI_SUGGESTIONS]\n'; out += `LEVEL: ${skillLevel}\nDEPTH: ${skillLevel === 'ADVANCED' ? 'deep technical' : skillLevel === 'INTERMEDIATE' ? 'practical' : 'step by step'}\n`; if (detectedIntents.length) out += `PRIMARY_INTENT: ${detectedIntents[0]}\n`; }

  if (files.length) {
    out += '\n## [OUTPUT_FILES]\n';
    files.forEach(f => { out += `\n--- ${f.name} ---\n${f.mode === 'full' ? f.content : f.summary}\n`; });
  }
  if (isOn('o-raw')) out += '\n## [RAW_ARCHIVE]\n' + $('chat-input').value;
  return out;
}

function buildAIPrompt(chat, template) {
  const tmplText = template ? `${template.text}\n\n` : '';
  const fileSection = files.length
    ? `\n\n═══════════════════════════════════════\nOUTPUT FILES (${files.length})\n═══════════════════════════════════════\n${files.map(f => `\n--- ${f.name} (${f.type.toUpperCase()}) ---\n${f.mode === 'full' ? f.content : f.summary}`).join('\n')}`
    : '';
  return `${tmplText}You are a Chat History Analyzer, Context Reconstructor, and AI Memory Extractor.\n\nAnalyze the conversation${files.length ? ' and output files' : ''} below. Produce a structured AI-optimized intelligence package. Optimize for machine readability. No preamble. Output only structured sections.\n\n═══════════════════════════════════════\nCONVERSATION:\n═══════════════════════════════════════\n${chat}${fileSection}\n═══════════════════════════════════════\n\nOUTPUT THESE SECTIONS:\n\n## [INTERACTION_FLOW]\nLogical blocks:\n  BLOCK_N:\n    INTENT: core user intent${isOn('o-importance') ? '\n    IMPORTANCE: [CRITICAL|HIGH|MEDIUM|LOW]' : ''}\n    OUTCOME: result/decision\n    STATUS: [RESOLVED|OPEN]\n\n## [MEMORY_LAYER]\n[TAG${isOn('o-confidence') ? '|CONFIDENCE' : ''}] description\nTags: SKILL/GOAL/PROJECT/TOOL/PREFERENCE/DOMAIN\n\n## [NAMED_ENTITIES]\nFILES: | URLS: | VERSIONS: | ERRORS:\n\n## [INTENT_SUMMARY]\nTOPIC: | WHY: | INTENTS: | DIRECTION: | OPEN_QUESTIONS:${files.length ? '\n\n## [OUTPUT_FILES_CONTEXT]\nFor each file: purpose, state, dependencies, issues, next steps.' : ''}${isOn('o-progression') ? '\n\n## [SKILL_PROGRESSION]\nSKILL | START → END | EVIDENCE' : ''}${isOn('o-conflict') ? '\n\n## [CONFLICT_DETECTION]\nN | TYPE | DESCRIPTION | STATUS' : ''}${isOn('o-suggestions') ? '\n\n## [AI_SUGGESTIONS]\nNEXT_TOPICS: | GAPS: | PROMPTING_STYLE: | DEPTH:' : ''}${isOn('o-raw') ? '\n\n## [RAW_ARCHIVE]\nVerbatim conversation.' : ''}\n\nRULES: Max density. Zero filler. AI-to-AI handoff.`;
}

function buildFilesOnlyPrompt() {
  if (!files.length) return '';
  return `Analyze these output files from an AI session. For each: PURPOSE, KEY_LOGIC, DEPENDENCIES, CURRENT_STATE, NEXT_STEPS.\n\n${files.map(f => `--- ${f.name} ---\n${f.mode === 'full' ? f.content : f.summary}`).join('\n\n')}`;
}

// ── TEMPLATES ─────────────────────────────────────────────────────────
function renderTemplates() {
  const grid = $('tmpl-grid');
  if (!grid) return;
  grid.innerHTML = TEMPLATES.map(t =>
    `<div class="tmpl ${selectedTemplate?.id === t.id ? 'active' : ''}" data-id="${t.id}"><div class="tmpl-name">${t.name}</div><div class="tmpl-preview">${t.text.substring(0, 45)}...</div></div>`
  ).join('');
  grid.querySelectorAll('.tmpl').forEach(el => {
    el.addEventListener('click', () => selectTemplate(el.dataset.id));
  });
}

function selectTemplate(id) {
  if (promptLocked) return;
  selectedTemplate = selectedTemplate?.id === id ? null : TEMPLATES.find(t => t.id === id);
  renderTemplates();
  const chat = $('chat-input').value.trim();
  if (chat) {
    const p = buildAIPrompt(chat, selectedTemplate);
    $('prompt-preview').innerText = p;
    $('prompt-raw').textContent = p;
    renderTokenMeter('token-meter-prompt', p);
  }
}

// ── EDIT MODE ─────────────────────────────────────────────────────────
function toggleEdit() {
  editMode = !editMode;
  document.querySelectorAll('.bb[data-editable]').forEach(el => {
    el.contentEditable = editMode ? 'true' : 'false';
  });
  document.querySelectorAll('.blk-del').forEach(el => {
    el.style.display = editMode ? 'inline-flex' : 'none';
  });
  const btn = $('edit-btn');
  btn.innerHTML = editMode ? '✓ Done' : '✏️ Edit';
  btn.style.color = editMode ? 'var(--g)' : '';
}

function rebuildRaw() {
  let text = '';
  document.querySelectorAll('.bb[data-editable]').forEach(el => {
    const tag = el.closest('.ob')?.querySelector('.btag')?.textContent || 'SECTION';
    text += `## [${tag.replace(/ /g, '_')}]\n${el.innerText}\n\n`;
  });
  $('local-raw').textContent = text;
  renderTokenMeter('token-meter-extract', text);
}

// ── RENDER EXTRACT BLOCKS ─────────────────────────────────────────────
const TAG_MAP = {
  INTERACTION_FLOW: ['t1', 'Interaction Flow'], MEMORY_LAYER: ['t2', 'Memory Layer'],
  NAMED_ENTITIES: ['t5', 'Named Entities'], INTENT_SUMMARY: ['t3', 'Intent Summary'],
  TOPIC_MAP: ['t4', 'Topic Map'], SKILL_PROGRESSION: ['t3', 'Skill Progression'],
  CONFLICT_DETECTION: ['t1', 'Conflict Detection'], AI_SUGGESTIONS: ['t2', 'AI Suggestions'],
  OUTPUT_FILES: ['t5', 'Output Files'], RAW_ARCHIVE: ['t6', 'Raw Archive']
};

function renderLocalBlocks(text) {
  const container = $('local-blocks');
  container.innerHTML = '';
  text.split(/(?=## \[)/g).filter(Boolean).forEach(sec => {
    const m = sec.match(/## \[([A-Z_]+)\]([\s\S]*)/);
    if (!m) return;
    const [tc, label] = TAG_MAP[m[1]] || ['t6', m[1]];
    const d = document.createElement('div');
    d.className = 'ob';
    d.innerHTML = `
      <div class="bh block-header">
        <span class="btag ${tc}">${m[1].replace(/_/g, ' ')}</span>
        <span class="btitle">${label}</span>
        <button class="btn-sm r blk-del" data-block style="display:none;padding:2px 6px;font-size:.54rem;margin-left:auto">×</button>
        <span class="chev">▼</span>
      </div>
      <div class="bb" data-editable="true" contenteditable="false">${esc(m[2].trim())}</div>`;
    container.appendChild(d);
  });

  // Wire block headers and delete buttons
  container.querySelectorAll('.block-header').forEach(hdr => {
    hdr.addEventListener('click', (e) => {
      if (e.target.dataset.block !== undefined) return; // don't collapse when clicking delete
      togB(hdr);
    });
  });
  container.querySelectorAll('.blk-del').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.closest('.ob').remove();
      rebuildRaw();
    });
  });
}

// ── MAIN RUN ──────────────────────────────────────────────────────────
function runAll() {
  const chat = $('chat-input').value.trim();
  if (!chat || chat.length < 20) { alert('Paste a chat conversation first.'); return; }
  editMode = false;

  const result = smartExtract(chat);
  const localText = buildLocalOutput(result);
  const promptText = buildAIPrompt(chat, selectedTemplate);
  const filesText = buildFilesOnlyPrompt();

  // Extract tab
  renderLocalBlocks(localText);
  $('local-raw').textContent = localText;
  if (files.length) {
    const fRaw = files.map(f => `--- ${f.name} ---\n${f.mode === 'full' ? f.content : f.summary}`).join('\n\n');
    $('files-raw').textContent = fRaw;
    $('cb-files').style.display = 'inline-flex';
  }
  renderTokenMeter('token-meter-extract', localText);
  $('extract-empty').style.display = 'none';
  $('extract-out').style.display = 'block';

  // Prompt tab
  renderTemplates();
  $('prompt-preview').innerText = promptText;
  $('prompt-raw').textContent = promptText;
  if (files.length) {
    $('prompt-files-raw').textContent = filesText;
    $('cb-files-prompt').style.display = 'inline-flex';
  }
  renderTokenMeter('token-meter-prompt', promptText);
  $('prompt-stat').textContent = `~${countTokens(promptText).toLocaleString()} tokens`;
  $('prompt-empty').style.display = 'none';
  $('prompt-out').style.display = 'block';

  $('footer-stat').textContent = `${result.userMsgs.length} msgs · ${result.blocks.length} blocks · ${files.length} files`;
  sw('extract');
  autoSaveState();
}

// ── SESSIONS ──────────────────────────────────────────────────────────
function loadSessionsFromStorage() {
  chrome.storage.local.get('cce_sessions', data => {
    sessions = data.cce_sessions || [];
    renderSessions();
  });
}

function saveSession() {
  const chat = $('chat-input').value.trim();
  const name = $('session-name').value.trim() || 'Session ' + new Date().toLocaleDateString();
  if (!chat) { alert('No chat to save.'); return; }
  const id = 's' + Date.now();
  sessions.unshift({ id, name, chat, files: [...files], created: new Date().toISOString(), tokens: countTokens(chat) });
  if (sessions.length > 50) sessions.pop();
  chrome.storage.local.set({ cce_sessions: sessions }, () => {
    chrome.runtime.sendMessage({ type: 'UPDATE_BADGE' });
    renderSessions();
    alert(`"${name}" saved!`);
  });
}

function loadSession(id) {
  const s = sessions.find(s => s.id === id);
  if (!s) return;
  $('chat-input').value = s.chat;
  $('session-name').value = s.name;
  files = s.files ? [...s.files] : [];
  renderFiles(); updateBadge();
  sw('chat');
}

function deleteSession(id) {
  if (!confirm('Delete this session?')) return;
  sessions = sessions.filter(s => s.id !== id);
  chrome.storage.local.set({ cce_sessions: sessions }, () => {
    chrome.runtime.sendMessage({ type: 'UPDATE_BADGE' });
    renderSessions();
  });
}

function renderSessions() {
  const list = $('sessions-list');
  const empty = $('sessions-empty');
  const mList = $('merge-list');
  if (!sessions.length) { empty.style.display = 'block'; list.innerHTML = ''; mList.innerHTML = ''; return; }
  empty.style.display = 'none';

  list.innerHTML = sessions.map(s =>
    `<div class="sess-item">
      <div class="sess-dot"></div>
      <div style="flex:1;min-width:0">
        <div class="sess-name">${esc(s.name)}</div>
        <div class="sess-meta">${new Date(s.created).toLocaleDateString()} · ~${(s.tokens || 0).toLocaleString()} tokens</div>
      </div>
      <div class="sess-btns">
        <button class="btn-sm p load-sess" data-id="${s.id}" style="padding:3px 7px">Load</button>
        <button class="btn-sm r del-sess" data-id="${s.id}" style="padding:3px 6px">×</button>
      </div>
    </div>`
  ).join('');

  list.querySelectorAll('.load-sess').forEach(btn => btn.addEventListener('click', () => loadSession(btn.dataset.id)));
  list.querySelectorAll('.del-sess').forEach(btn => btn.addEventListener('click', () => deleteSession(btn.dataset.id)));

  mList.innerHTML = sessions.map(s =>
    `<div class="sess-item merge-item ${mergeSelected.includes(s.id) ? 'selected' : ''}" data-id="${s.id}" style="${mergeSelected.includes(s.id) ? 'border-color:rgba(108,99,255,.4);background:rgba(108,99,255,.07)' : ''}">
      <div style="width:13px;height:13px;border-radius:3px;border:1.5px solid var(--b2);display:flex;align-items:center;justify-content:center;font-size:.5rem;color:#fff;flex-shrink:0;${mergeSelected.includes(s.id) ? 'background:var(--p);border-color:var(--p)' : ''}">${mergeSelected.includes(s.id) ? '✓' : ''}</div>
      <div class="sess-name">${esc(s.name)}</div>
      <div class="sess-meta">${new Date(s.created).toLocaleDateString()}</div>
    </div>`
  ).join('');

  mList.querySelectorAll('.merge-item').forEach(el => {
    el.addEventListener('click', () => toggleMerge(el.dataset.id));
  });

  $('merge-btns').style.display = mergeSelected.length > 1 ? 'flex' : 'none';
}

function toggleMerge(id) {
  mergeSelected = mergeSelected.includes(id) ? mergeSelected.filter(i => i !== id) : [...mergeSelected, id];
  renderSessions();
}

function mergeSessions() {
  const sel = sessions.filter(s => mergeSelected.includes(s.id));
  if (sel.length < 2) { alert('Select at least 2 sessions.'); return; }
  const merged = sel.map(s => `\n=== SESSION: ${s.name} (${new Date(s.created).toLocaleDateString()}) ===\n${s.chat}`).join('\n\n');
  $('chat-input').value = merged;
  $('session-name').value = 'Merged: ' + sel.map(s => s.name).join(' + ');
  sel.forEach(s => { if (s.files) s.files.forEach(f => { if (!files.find(ef => ef.name === f.name)) files.push(f); }); });
  renderFiles(); updateBadge();
  mergeSelected = []; renderSessions();
  sw('chat');
  alert(`Merged ${sel.length} sessions. Review and hit Extract.`);
}

function exportSessions() {
  if (!sessions.length) { alert('No sessions to export.'); return; }
  const blob = new Blob([JSON.stringify(sessions, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'cce_sessions.json'; a.click();
  URL.revokeObjectURL(url);
}

function importSessions(input) {
  const file = input.files[0]; if (!file) return;
  const r = new FileReader();
  r.onload = e => {
    try {
      const imported = JSON.parse(e.target.result);
      if (!Array.isArray(imported)) throw new Error();
      const existing = new Set(sessions.map(s => s.id));
      imported.forEach(s => { if (!existing.has(s.id)) sessions.push(s); });
      if (sessions.length > 50) sessions = sessions.slice(0, 50);
      chrome.storage.local.set({ cce_sessions: sessions }, () => {
        chrome.runtime.sendMessage({ type: 'UPDATE_BADGE' });
        renderSessions();
        alert(`Imported ${imported.length} sessions.`);
      });
    } catch { alert('Invalid JSON file.'); }
  };
  r.readAsText(file);
  input.value = '';
}

// ── AUTO-SAVE ─────────────────────────────────────────────────────────
function autoSaveState() {
  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(() => {
    const state = {
      chat: $('chat-input').value,
      sessionName: $('session-name').value,
      files: files.map(f => ({ ...f })),
    };
    chrome.storage.local.set({ cce_form_state: state });
  }, 800);
}

function restoreFormState() {
  chrome.storage.local.get('cce_form_state', data => {
    if (!data.cce_form_state) return;
    const s = data.cce_form_state;
    if (s.chat) $('chat-input').value = s.chat;
    if (s.sessionName) $('session-name').value = s.sessionName;
    if (s.files && s.files.length) { files = s.files; renderFiles(); updateBadge(); }
  });
}

// ── INIT — all event listeners wired here ────────────────────────────
document.addEventListener('DOMContentLoaded', () => {

  // Nav tabs
  ['chat', 'files', 'extract', 'prompt', 'sessions', 'guide'].forEach(name => {
    $('tab-btn-' + name)?.addEventListener('click', () => sw(name));
  });
  $('nav-sessions-btn')?.addEventListener('click', () => sw('sessions'));
  $('nav-guide-btn')?.addEventListener('click', () => sw('guide'));
  $('fullmode-btn')?.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?fullmode=1') });
  });

  // Opts toggles
  ['o-importance', 'o-confidence', 'o-conflict', 'o-progression', 'o-suggestions', 'o-entities', 'o-raw'].forEach(id => {
    $(id)?.addEventListener('click', () => tog($(id)));
  });

  // Chat tab
  $('scrape-btn')?.addEventListener('click', detectAndScrape);
  $('refresh-scrape-btn')?.addEventListener('click', detectAndScrape);
  $('extract-btn')?.addEventListener('click', runAll);
  $('chat-input')?.addEventListener('input', autoSaveState);
  $('session-name')?.addEventListener('input', autoSaveState);

  // Files tab
  $('drop-zone')?.addEventListener('click', () => $('file-input').click());
  $('drop-zone')?.addEventListener('dragover', e => { e.preventDefault(); $('drop-zone').style.borderColor = 'var(--g)'; });
  $('drop-zone')?.addEventListener('dragleave', () => { $('drop-zone').style.borderColor = ''; });
  $('drop-zone')?.addEventListener('drop', e => { e.preventDefault(); $('drop-zone').style.borderColor = ''; handleFiles(e.dataTransfer.files); });
  $('file-input')?.addEventListener('change', function () { handleFiles(this.files); });
  $('add-file-btn')?.addEventListener('click', addPastedFile);
  $('clear-files-btn')?.addEventListener('click', clearFiles);

  // Extract tab
  $('cb-all')?.addEventListener('click', () => copyText($('local-raw').textContent, 'cb-all', '📋 Copy All', '✓ Copied!'));
  $('cb-files')?.addEventListener('click', () => copyText($('files-raw').textContent, 'cb-files', '📁 Files Only', '✓ Copied!'));
  $('edit-btn')?.addEventListener('click', toggleEdit);

  // Prompt tab
  $('cb-prompt')?.addEventListener('click', () => copyText($('prompt-preview').innerText, 'cb-prompt', '📋 Copy Prompt', '✓ Copied!'));
  $('cb-files-prompt')?.addEventListener('click', () => copyText($('prompt-files-raw').textContent, 'cb-files-prompt', '📁 Files Prompt', '✓ Copied!'));
  $('lock-btn')?.addEventListener('click', () => {
    promptLocked = !promptLocked;
    $('lock-btn').innerHTML = promptLocked ? '🔒 Locked' : '🔓 Lock Edits';
    $('lock-btn').style.color = promptLocked ? 'var(--o)' : '';
  });
  $('prompt-bh')?.addEventListener('click', () => togB($('prompt-bh')));

  // Sessions tab
  $('save-session-btn')?.addEventListener('click', saveSession);
  $('export-sessions-btn')?.addEventListener('click', exportSessions);
  $('import-sessions-btn')?.addEventListener('click', () => $('import-input').click());
  $('import-input')?.addEventListener('change', function () { importSessions(this); });
  $('merge-confirm-btn')?.addEventListener('click', mergeSessions);
  $('merge-clear-btn')?.addEventListener('click', () => { mergeSelected = []; renderSessions(); });

  // Guide collapsibles
  document.querySelectorAll('.guide-bh').forEach(hdr => {
    hdr.addEventListener('click', () => togB(hdr));
  });

  // Init
  detectPlatform();
  loadSessionsFromStorage();
  restoreFormState();
  renderTemplates();
});
