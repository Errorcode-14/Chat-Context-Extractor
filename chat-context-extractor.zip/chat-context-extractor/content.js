// ── CONTENT SCRIPT ───────────────────────────────────────────────────
// Runs on ChatGPT, Claude, Gemini pages
// Scrapes conversation messages from the DOM

(function () {
  // Detect platform from URL
  function detectPlatform() {
    const h = location.hostname;
    if (h.includes('chatgpt.com') || h.includes('chat.openai.com')) return 'chatgpt';
    if (h.includes('claude.ai')) return 'claude';
    if (h.includes('gemini.google.com')) return 'gemini';
    return 'unknown';
  }

  // ── CHATGPT SCRAPER ──────────────────────────────────────────────
  function scrapeChatGPT() {
    const messages = [];
    // ChatGPT uses data-message-author-role attributes
    const turns = document.querySelectorAll('[data-message-author-role]');
    if (turns.length) {
      turns.forEach(el => {
        const role = el.getAttribute('data-message-author-role');
        const textEl = el.querySelector('.whitespace-pre-wrap, [class*="prose"], .markdown');
        const text = textEl ? textEl.innerText.trim() : el.innerText.trim();
        if (text) {
          messages.push({
            role: role === 'user' ? 'User' : 'Assistant',
            text
          });
        }
      });
    }
    // Fallback: article-based structure
    if (!messages.length) {
      const articles = document.querySelectorAll('article[data-testid*="conversation-turn"]');
      articles.forEach(a => {
        const isUser = a.querySelector('[data-message-author-role="user"]') ||
          a.classList.toString().includes('user');
        const text = a.innerText.trim();
        if (text) messages.push({ role: isUser ? 'User' : 'Assistant', text });
      });
    }
    return messages;
  }

  // ── CLAUDE SCRAPER ───────────────────────────────────────────────
  function scrapeClaude() {
    const messages = [];
    // Claude uses data-testid on message containers
    const humanMsgs = document.querySelectorAll('[data-testid="human-turn"], .human-turn, [class*="HumanTurn"]');
    const aiMsgs = document.querySelectorAll('[data-testid="ai-turn"], .ai-turn, [class*="AssistantTurn"]');

    // Try paired approach first
    if (humanMsgs.length || aiMsgs.length) {
      const allTurns = [
        ...[...humanMsgs].map(el => ({ role: 'User', el })),
        ...[...aiMsgs].map(el => ({ role: 'Assistant', el }))
      ].sort((a, b) => {
        const pos = a.el.compareDocumentPosition(b.el);
        return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
      });
      allTurns.forEach(({ role, el }) => {
        const text = el.innerText.trim();
        if (text) messages.push({ role, text });
      });
    }

    // Fallback: look for conversation containers
    if (!messages.length) {
      const containers = document.querySelectorAll('[class*="message"], [class*="Message"]');
      containers.forEach((el, i) => {
        const text = el.innerText.trim();
        if (text.length > 5) {
          messages.push({ role: i % 2 === 0 ? 'User' : 'Assistant', text });
        }
      });
    }
    return messages;
  }

  // ── GEMINI SCRAPER (best effort) ─────────────────────────────────
  function scrapeGemini() {
    const messages = [];
    // Gemini uses model-response and user-query elements
    const userEls = document.querySelectorAll('.user-query, [class*="user-query"], query-text, .query-text');
    const aiEls = document.querySelectorAll('model-response, [class*="model-response"], .model-response, response-container');

    if (userEls.length || aiEls.length) {
      // Interleave by DOM position
      const all = [
        ...[...userEls].map(el => ({ role: 'User', el })),
        ...[...aiEls].map(el => ({ role: 'Assistant', el }))
      ].sort((a, b) => {
        try {
          const pos = a.el.compareDocumentPosition(b.el);
          return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
        } catch { return 0; }
      });
      all.forEach(({ role, el }) => {
        const text = el.innerText?.trim();
        if (text && text.length > 3) messages.push({ role, text });
      });
    }
    return messages;
  }

  // ── FORMAT OUTPUT ────────────────────────────────────────────────
  function formatMessages(messages) {
    return messages.map(m => `${m.role}: ${m.text}`).join('\n\n');
  }

  // ── RETRY WRAPPER ────────────────────────────────────────────────
  function scrapeWithRetry(platform, attempt = 0) {
    let messages = [];
    try {
      if (platform === 'chatgpt') messages = scrapeChatGPT();
      else if (platform === 'claude') messages = scrapeClaude();
      else if (platform === 'gemini') messages = scrapeGemini();
    } catch (e) {
      return { error: 'Scrape error: ' + e.message };
    }

    if (!messages.length && attempt < 2) {
      // DOM might not be ready — signal to retry
      return { retry: true };
    }

    if (!messages.length) {
      return { error: 'no_messages', platform };
    }

    return {
      ok: true,
      platform,
      text: formatMessages(messages),
      count: messages.length
    };
  }

  // ── MESSAGE LISTENER ─────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // Only accept messages from our own extension
    if (sender.id !== chrome.runtime.id) return;
    if (msg.type === 'SCRAPE') {
      const platform = detectPlatform();
      const result = scrapeWithRetry(platform);

      if (result.retry) {
        // Wait for dynamic content and retry
        setTimeout(() => {
          const retryResult = scrapeWithRetry(platform, 1);
          if (retryResult.retry) {
            setTimeout(() => {
              sendResponse(scrapeWithRetry(platform, 2));
            }, 1200);
          } else {
            sendResponse(retryResult);
          }
        }, 800);
        return true; // async
      }

      sendResponse(result);
    }
    return true;
  });
})();
