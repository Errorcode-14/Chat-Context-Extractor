# Chat Context Extractor — Chrome Extension

Extract structured AI-optimized context from ChatGPT, Claude, and Gemini chats.
No API. No account. Free forever.

---


## Install in Chrome

1. Open Chrome and go to: `chrome://extensions`
2. Enable **Developer mode** (toggle in the top-right corner)
3. Click **Load unpacked**
4. Select the `chat-context-extractor-extension` folder
5. The extension appears in your toolbar — pin it for easy access

---

## Folder Structure

```
chat-context-extractor-extension/
  manifest.json      — extension config
  popup.html         — the UI
  popup.js           — all logic
  styles.css         — styling
  content.js         — page scraper (ChatGPT, Claude, Gemini)
  background.js      — service worker (badge, shortcuts, context menu)
  icons/
    icon.svg         — source icon (convert this to PNG)
    icon16.png       — required (you create from SVG)
    icon48.png       — required (you create from SVG)
    icon128.png      — required (you create from SVG)
  README.md          — this file
```

---

## How to Use

### Auto-Scrape
1. Open any ChatGPT, Claude, or Gemini conversation
2. Click the extension icon
3. Hit **Auto-Scrape This Chat** — messages are pulled automatically
4. If scraping fails, paste the conversation manually in the text area

### Extract Context
1. Optionally add output files in the **Files** tab
2. Hit **Extract Everything**
3. **Extract tab** — local instant analysis, copy as context
4. **AI Prompt tab** — full mega-prompt, paste into any AI for deep analysis

### Use Context in a New Chat
Paste the copied context at the top of any new AI chat, then say:

> "This is structured context from a previous conversation. Use it to understand my background and continue helping me."

### Sessions
- Name your session and click **Save Session** to persist it
- Sessions stored locally in your browser — private, no cloud
- Export as JSON to back up or transfer sessions
- Select multiple sessions and **Merge** them for multi-chat projects

---

## Keyboard Shortcut

`Ctrl+Shift+E` (Windows/Linux) or `Cmd+Shift+E` (Mac) — opens the popup from any page.

To customize: go to `chrome://extensions/shortcuts`

---

## Platform Support

| Platform | Auto-Scrape | Notes |
|----------|-------------|-------|
| ChatGPT  | ✅ Full | Works on chatgpt.com and chat.openai.com |
| Claude   | ✅ Full | Works on claude.ai |
| Gemini   | ⚡ Best effort | Falls back to manual if DOM changes |
| Others   | ➕ Manual | Paste conversation in the text area |

---

## Updating the Extension

If you make changes to any file:
1. Go to `chrome://extensions`
2. Find Chat Context Extractor
3. Click the **refresh icon** (↺)

---

## Troubleshooting

**"Could not load manifest"**
→ Make sure all 3 PNG icons exist in the `icons/` folder before loading

**Auto-scrape returns 0 messages**
→ Scroll through the full conversation first to let the page load all messages, then re-scrape

**Extension popup closes and loses my work**
→ Form state is auto-saved every second — reopen the popup and your chat/files will still be there

**Gemini scrape fails**
→ Paste the conversation manually — Gemini's DOM changes frequently
